package by.itacademy.dz.carsapp.db;

import by.itacademy.dz.carsapp.db.table.Brand;

public class BrandDaoImpl extends AbstractDao<Brand> {

}
