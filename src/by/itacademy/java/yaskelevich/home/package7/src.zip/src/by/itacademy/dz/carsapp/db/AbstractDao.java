package by.itacademy.dz.carsapp.db;

public abstract class AbstractDao<T> {

}
