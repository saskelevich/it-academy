package by.itacademy.dz.carsapp.db.table;

public class Brand {

}
