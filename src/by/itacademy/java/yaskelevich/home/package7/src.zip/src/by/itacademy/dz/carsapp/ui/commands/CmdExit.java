package by.itacademy.dz.carsapp.ui.commands;

@Command(name = "exit")
public class CmdExit extends AbstractCmd {

	@Override
	public AbstractCmd execute() {
		return null;
	}
}
