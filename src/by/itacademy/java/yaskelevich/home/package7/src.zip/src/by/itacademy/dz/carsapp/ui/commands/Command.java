package by.itacademy.dz.carsapp.ui.commands;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface Command {
	String name();

	String description() default "";
}
