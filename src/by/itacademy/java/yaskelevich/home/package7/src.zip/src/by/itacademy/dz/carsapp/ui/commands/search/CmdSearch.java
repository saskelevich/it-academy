package by.itacademy.dz.carsapp.ui.commands.search;

import by.itacademy.dz.carsapp.ui.commands.AbstractCmd;
import by.itacademy.dz.carsapp.ui.commands.Command;

@Command(name = "search", description = "������ �����")
public class CmdSearch extends AbstractCmd {

}
